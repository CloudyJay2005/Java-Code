/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject13;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class Mavenproject13 {

    public class Account {
       private String username;
       private String password;
       private String firstName;
       private String lastName;
       
       //Constructor
       public Account (String username, String password, String firstName, String
                       lastName){
           this.username = username;
           this.password = password;
           this.firstName = firstName;
           this.lastName = lastName;
       }
       //Getters and Setters
       public String getUsername(){
           return username;
       }
       public void setUsername(String username){
           this.username = username;
       }
       public String getPassword(){
           return password;
       }
       public void setPassword(String password){
           this.password = password;
       }
       public String getFirstName(){
           return firstName;
       }
       public void setFirstName(String firstName){
           this.firstName = firstName;
       }
       public String getLastName(){
           return lastName;
       }
       public void setLastName(String lastName){
           this.lastName = lastName;
       }
       
       //toString method to print account details
         @Override
         public String toString(){
             return "Account Details:\n"+
                     "Username: " + username +
            "\n" +   
                     "Password: " + password +
            "\n" +
                     "Name: " + firstName + "" +
            lastName;         
         }
         
         public class Main{
            public static void main(String args)
             {
                 Scanner scanner = new Scanner(System.in);
                 System.out.println("Create Account");
                 System.out.println("-------------");
                 
                 System.out.print("Enter username:");
                 String username =
                         scanner.nextLine();
                 
                 System.out.print("Enter password:");
                 String password =
                         scanner.nextLine();
                 
                 System.out.print("Enter first name:");
                 String firstName =
                         scanner.nextLine();
                 
                 System.out.print("Enter last name:");
                 String lastName =
                         scanner.nextLine();{
                 
             }
                 
                 //public class Account
                 Account account = new
                 System.out.println("\nAccount Created Successfully!");
                 System.out.println(account);
                        
            
             }
                 
             
                 
         }
    }

}